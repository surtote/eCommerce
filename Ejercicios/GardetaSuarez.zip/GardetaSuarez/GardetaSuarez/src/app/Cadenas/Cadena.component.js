"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var CadenaService_1 = require("./CadenaService");
var CadenaComponent = (function () {
    function CadenaComponent(cadenaService, activatedRoute) {
        this.cadenaService = cadenaService;
        this.activatedRoute = activatedRoute;
    }
    CadenaComponent.prototype.ngOnInit = function () {
        var _this = this;
        var nomCadena = this.activatedRoute.snapshot.params['nombre'];
        this.cadenaService.getCadenasPorNombre(nomCadena).subscribe(function (cadenaDatos) { return _this.cadena = cadenaDatos; });
    };
    return CadenaComponent;
}());
CadenaComponent = __decorate([
    core_1.Component({
        selector: 'la-cadena',
        templateUrl: 'app/Cadena/Cadena.component.html',
    }),
    __metadata("design:paramtypes", [CadenaService_1.CadenasService, router_1.ActivatedRoute])
], CadenaComponent);
exports.CadenaComponent = CadenaComponent;
//# sourceMappingURL=Cadena.component.js.map