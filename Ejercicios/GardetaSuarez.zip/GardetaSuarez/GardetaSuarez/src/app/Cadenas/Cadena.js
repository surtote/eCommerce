"use strict";
var Cadena = (function () {
    function Cadena(ID, Nombre, DireccionSede, Ciudad) {
        this.ID = ID;
        this.Nombre = Nombre;
        this.DireccionSede = DireccionSede;
        this.Ciudad = Ciudad;
    }
    return Cadena;
}());
exports.Cadena = Cadena;
//# sourceMappingURL=Cadena.js.map