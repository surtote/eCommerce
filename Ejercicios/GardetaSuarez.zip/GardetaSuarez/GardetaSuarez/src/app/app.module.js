"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require("@angular/core");
var platform_browser_1 = require("@angular/platform-browser");
var http_1 = require("@angular/http");
var router_1 = require("@angular/router");
var app_component_1 = require("./app.component");
var CadenaService_1 = require("./Cadenas/CadenaService");
var CadenaLista_component_1 = require("./Cadenas/CadenaLista.component");
var HotelService_1 = require("./Hoteles/HotelService");
var Hotel_component_1 = require("./Hoteles/Hotel.component");
var HotelLista_component_1 = require("./Hoteles/HotelLista.component");
var Cadena_component_1 = require("./Cadenas/Cadena.component");
var appRutas = [
    { path: 'Cadena', component: CadenaLista_component_1.CadenaListaComponent },
    { path: 'Hotel/:Nombre', component: Hotel_component_1.HotelComponent },
    { path: 'Cadena/:nombre', component: CadenaLista_component_1.CadenaListaComponent },
    { path: 'Hotel', component: HotelLista_component_1.HotelListaComponent },
];
var AppModule = (function () {
    function AppModule() {
    }
    return AppModule;
}());
AppModule = __decorate([
    core_1.NgModule({
        imports: [platform_browser_1.BrowserModule, http_1.HttpModule, router_1.RouterModule.forRoot(appRutas)],
        declarations: [app_component_1.AppComponent, CadenaLista_component_1.CadenaListaComponent, Hotel_component_1.HotelComponent, HotelLista_component_1.HotelListaComponent, Cadena_component_1.CadenaComponent],
        bootstrap: [app_component_1.AppComponent],
        providers: [CadenaService_1.CadenasService, HotelService_1.HotelService]
    })
], AppModule);
exports.AppModule = AppModule;
//# sourceMappingURL=app.module.js.map