"use strict";
var Hotel = (function () {
    function Hotel(ID, Nombre, Ciudad, Direccion) {
        this.ID = ID;
        this.Nombre = Nombre;
        this.Ciudad = Ciudad;
        this.Direccion = Direccion;
    }
    return Hotel;
}());
exports.Hotel = Hotel;
//# sourceMappingURL=Hotel.js.map